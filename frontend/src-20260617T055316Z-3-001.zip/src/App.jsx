import Home from "./pages/Home";
import About from "./pages/About";
import Contact from "./pages/Contact";
import {BrowserRouter, Routes, Route, Link} from "react-router-dom";
import Layout from "./components/Layout";
import Headerdown from "./Headerdown";
import "./App.css";
function App(){
  return(
   <BrowserRouter>
   
    <Routes>
      <Route path="/" element={<Layout/>}>
      <Route path="/" element={<Home/>}/> 
      <Route path="/about" element={<About/>}/> 
      <Route path="/food-board" element={<Food/>}/>
      <Route path="/contact" element={<Contact/>}/> 
      </Route>
    </Routes>

    </BrowserRouter>
  );
   
}
export default App;
