function Footer(){
    return(
        <div className="bg-light p-3 text-center">
             &copy;2026 Bright Future Academy. All rights Reserved.
            <p>Email:brightfutureacademy@gmail.com</p>
        </div>
    );
}
export default Footer;