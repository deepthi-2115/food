import {Link} from "react-router-dom";
function Header(){
    return(
            <div className="row bg-light p-3">
                <div className="col-md-6">
                    <h1 className="text-primary fw-bold">Bright Future Academy</h1>
                     <p className="text-dark">Learn Today, Lead Tomorrow</p>
                </div>
            <div className="col-md-6 text-md-end">
                <nav>
                    <Link to="/" className="me-3">Home</Link>
                    <Link to="/about" className="me-3">About</Link> 
                    <Link to="/courses" className="me-3">Courses</Link>
                    <Link to="/contact" className="me-3">Contact</Link>
                </nav>
            </div>
            </div>
    );
}
export default Header;