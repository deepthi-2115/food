import {useState} from "react";
function Login(){
    const[email,setEmail]=useState(0);
    const[password,setPassword]=useState(0);
    return(
        <div className="container bg-light mt-3 p-5 rounded">
            <div className="row mt-4">
                <div className="col-md-6">

                </div>
                <div className="col-md-6">
                    <h2 className="fw-bold">Login Here</h2><br/>
                    <p className="text-secondary">Login to your account to continue</p>
                    <form>
                        <div className="mb-3">
                        <label className="form-label">Email</label><br/>
                        <input className="form-control" type="email" value={email} onChange={(e)=>setEmail(e.target.value)}/>
                        </div>

                        <div className="mb-3">
                        <label className="form-label">Password</label><br/>
                        <input className="form-control" type="password" 
                            value={password} onChange={(e)=>setPassword(e.target.value)}/>
                        </div>
                        <div className="row">
                            <div className="col-md-6">
                                <div className="form-check">
                                    <input className="form-check-input" type="checkbox" id="check2"></input>
                                    <label className="form-check-label">Remember me</label>
                                </div>
                            </div>
                            <div className="col-md-6">
                                <p className="text-primary text-right">Forget Password?</p>
                            </div>
                        </div>
                        <button type="submit" className="btn btn-primary text-white w-100">Login</button>
 <div className="d-flex text-align-center my-4">
                            <hr className="flex-grow-1"></hr>
                            <span className="text-muted mx-3">or</span>
                            <hr className="flex-grow-1"></hr>
                        </div>
                        <button type="submit" className="btn btn-outline-dark w-100">Login with Google</button>
                        <p className="text-center text-muted mt-3">Don't have an account?</p>
                       

                    </form>
                </div>
            </div>
        </div>
    )
}
export default Login;