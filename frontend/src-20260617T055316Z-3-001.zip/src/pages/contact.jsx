function Contact(){
    return(
        <div>
            <h3 className="p-3">Contact Us</h3>
            <p className="text-secondary p-3">We'd love to hear from you. Reach out to us for any queries or information</p>
           <div className="container m-6">
            <div className="row">
                <div className="col-md-6">
                    <h4 className="fw-bold m-3">Address</h4>
                    <p className="m-3">123 Learning Street, Education City, Knowledge Park, 560001</p>
                    <h4 className="fw-bold m-3">Phone</h4>
                    <p className="m-3">+91 9876543210</p>
                    <h4 className="fw-bold m-3">Email</h4>
                    <p className="m-3">info@brightfutureacademy.com</p>
                    <h4 className="fw-bold m-3">Office Hours</h4>
                    <p className="m-3">Monday - Saturday: 9:00 AM - -6:00 PM</p>
                </div>
              <div className="col-md-6 ml-5">
              <div className="card shadow">
            <div className="card-body">
                 <label className="form-label">Full Name</label>
              <input className="form-control mb-3" placeholder="Message"></input>
               <label className="form-label">Full Name</label>
              <input className="form-control mb-3" placeholder="Email Address"></input>
               <label className="form-label">Full Name</label>
              <textarea className="form-control mb-3" placeholder="Message"></textarea>
              <button className="btn btn-primary">Send Message</button>
            </div>
          </div>
</div>
                    </div>
                </div>
            </div>

    )
}
export default Contact;